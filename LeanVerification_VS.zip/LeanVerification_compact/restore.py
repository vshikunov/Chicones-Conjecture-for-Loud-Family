#!/usr/bin/env python3
"""Restore the original archive structure and verify every source file."""
import argparse
import base64
import hashlib
import json
import pathlib
import shutil
import sys
import tempfile
import zipfile

from sparse_codec import decode_bytes


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=pathlib.Path,
                        help='Output ZIP path; existing files are never overwritten.')
    arguments = parser.parse_args()
    folder = pathlib.Path(__file__).resolve().parent
    output = arguments.output or folder / 'LeanVerification_restored.zip'
    if output.exists():
        raise FileExistsError('Output already exists: ' + str(output))
    manifest = json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))
    if manifest.get('format') != 'lean-lossless-transport-v1':
        raise ValueError('Unsupported transport manifest')
    records = manifest['files']
    restored_count = 0
    restored_bytes = 0
    seen = set()

    def entry_info(metadata):
        name = metadata['filename']
        path = pathlib.PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or '\\' in name or ':' in name:
            raise ValueError('Unsafe archive entry name')
        info = zipfile.ZipInfo(name, tuple(metadata['date_time']))
        info.compress_type = metadata['compress_type']
        if info.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):
            raise ValueError('Unsupported output compression method')
        info._compresslevel = 9
        for key in ('create_system', 'create_version', 'extract_version',
                    'internal_attr', 'external_attr'):
            setattr(info, key, metadata[key])
        info.comment = base64.b64decode(metadata['comment'])
        info.extra = base64.b64decode(metadata['extra'])
        return info

    print('Restoring {} files. This can take a few minutes.'.format(len(records)), flush=True)
    print('Every restored file will be checked against its original SHA-256 hash.', flush=True)
    with zipfile.ZipFile(folder / 'payload.zip') as payload:
        def write_archive(tree, destination):
            nonlocal restored_count, restored_bytes
            with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED,
                                 compresslevel=9, allowZip64=True) as archive:
                archive.comment = base64.b64decode(tree['comment'])
                for entry in tree['entries']:
                    info = entry_info(entry['metadata'])
                    if entry['kind'] == 'directory':
                        archive.writestr(info, b'')
                    elif entry['kind'] == 'archive':
                        with tempfile.SpooledTemporaryFile(max_size=8 * 1024 * 1024) as nested:
                            write_archive(entry['archive'], nested)
                            nested.seek(0)
                            with archive.open(info, 'w', force_zip64=True) as target:
                                shutil.copyfileobj(nested, target, 1024 * 1024)
                    elif entry['kind'] == 'file':
                        index = entry['record']
                        if index in seen or not 0 <= index < len(records):
                            raise ValueError('Duplicate or invalid source record')
                        record = records[index]
                        data = payload.read(record['payload'])
                        if record['codec'] == 'sparse-v1':
                            data = decode_bytes(data)
                        elif record['codec'] != 'raw':
                            raise ValueError('Unsupported payload encoding')
                        if len(data) != record['size'] or hashlib.sha256(data).hexdigest() != record['sha256']:
                            raise ValueError('Integrity check failed: ' + record['path'])
                        archive.writestr(info, data)
                        seen.add(index)
                        restored_count += 1
                        restored_bytes += len(data)
                        if restored_count % 100 == 0 or restored_count == len(records):
                            print('Checked and restored {} / {} files'.format(restored_count, len(records)), flush=True)
                    else:
                        raise ValueError('Unknown archive entry kind')

        output.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(prefix='lean_restore_', suffix='.tmp',
                                         dir=output.parent, delete=False) as temporary:
            temporary_path = pathlib.Path(temporary.name)
        try:
            write_archive(manifest['archive_tree'], temporary_path)
            if restored_count != len(records) or restored_bytes != manifest['source_bytes']:
                raise ValueError('Restored archive is incomplete')
            # Exclusive creation also protects against another process creating
            # the selected output while the reconstruction is running.
            with output.open('xb') as target, temporary_path.open('rb') as source:
                shutil.copyfileobj(source, target, 1024 * 1024)
        finally:
            temporary_path.unlink(missing_ok=True)

    print('\nSUCCESS: all {} source files match their originals.'.format(restored_count))
    print('Created: ' + str(output.resolve()))
    print('The ZIP containers are recompressed; source-file contents and archive paths are unchanged.')


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('\nRESTORATION FAILED: ' + str(error), file=sys.stderr)
        sys.exit(1)
