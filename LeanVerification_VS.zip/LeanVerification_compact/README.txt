LEAN VERIFICATION - LOSSLESS COMPACT PACKAGE

This ZIP is a compact transport package. Extracting it is the first step;
run the included restoration script to recreate the complete original archive.

RESTORE ON WINDOWS
1. Extract this entire ZIP into a folder with at least 1 GB of free disk space.
2. Python 3.8 or later must be installed. No extra Python packages are needed.
3. Open the LeanVerification_compact folder and double-click Restore_Windows.bat.
4. Wait for SUCCESS. The new file is LeanVerification_restored.zip in that folder.
5. Use or extract that restored ZIP normally. It retains the original nested ZIP
   structure, folder names, and all original files.

You can also open a terminal in this folder and run:
    python restore.py
On systems where the command is python3, use:
    python3 restore.py

PRESERVATION
All 2,833 source files, totaling 411,233,781 uncompressed bytes, are preserved.
The large generated certificate literals are stored as exact integer arithmetic
instructions where this reproduces every byte of their original cached data.
All other content is stored verbatim. The restoration script checks every file
against its original size and SHA-256 hash before writing it into the archive.
No Lean or Python source from the supplied project is executed by this process.
No network connection is used. This check establishes file integrity only.

The original ZIP containers are rebuilt with ordinary DEFLATE compression.
Their compressed bytes may differ, but every contained source file is restored
byte for byte, and the original archive paths and hierarchy are preserved.
The restored full archive is larger than 25 MB; this compact transport ZIP is
the file to upload or send when the size limit is 25 MB.

Keep restore.py, sparse_codec.py, payload.zip, and manifest.json together.
Existing restored ZIPs are never overwritten. To use a different destination:
    python restore.py --output another_name.zip
