@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 restore.py
  goto finished
)
where python >nul 2>nul
if not errorlevel 1 (
  python restore.py
  goto finished
)
echo Python 3.8 or later is required.
echo If Python is already installed, open a terminal here and run: python restore.py
:finished
pause
