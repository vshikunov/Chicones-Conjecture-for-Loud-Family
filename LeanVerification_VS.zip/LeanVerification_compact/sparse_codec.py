#!/usr/bin/env python3
"""Lossless, dependency-free transport codec for sparse certificate literals.

This module does not alter, evaluate, or prove Lean source.  It stores an exact
certificate literal as its arithmetic instructions only when independent integer
arithmetic reproduces EVERY original cache and the complete literal bytes.
Unrecognized literals, auxiliary cache holders, and all other source bytes are
stored verbatim.  Decoding reconstructs the original source bytes.

API:
    encoded = encode_bytes(original_bytes)
    assert decode_bytes(encoded) == original_bytes

The caller should authenticate the complete restored file with its original
SHA-256 hash. Python 3's standard library is the only dependency.
"""

import json
import re
import struct


MAGIC = b"LEAN-SPARSE-LOSSLESS\x00\x01"
_SIZE = struct.Struct("<Q")
_LITERAL_PATTERN = re.compile(
    rb'(?m)^(.*?\bsparse_program(?:_array)?_literal%[ \t]*)("[^\n]*")([ \t]*\r?$)'
)


def _reconstruct_literal(operations, expected_entries=None):
    """Recreate sorted sparse caches and their exact generator JSON spelling."""
    if not isinstance(operations, list) or not operations:
        raise ValueError("An arithmetic program must be a nonempty list")
    if expected_entries is not None and len(expected_entries) != len(operations):
        raise ValueError("Certificate length mismatch")
    caches = []
    restored = []
    for index, operation in enumerate(operations):
        if not isinstance(operation, list) or len(operation) != 2:
            raise ValueError("Unsupported arithmetic instruction")
        opcode, operands = operation
        if type(opcode) is not int or not isinstance(operands, list):
            raise ValueError("Unsupported opcode or operand list")

        def previous(offset):
            if type(offset) is not int or offset < 0 or offset >= index:
                raise ValueError("Invalid backwards reference")
            return caches[index - 1 - offset]

        if opcode == 0 and len(operands) == 1:
            if not isinstance(operands[0], str):
                raise ValueError("Constant must be an integer string")
            coefficient = int(operands[0])
            polynomial = {(0, 0): coefficient} if coefficient else {}
        elif opcode == 1 and not operands:
            polynomial = {(1, 0): 1}
        elif opcode == 2 and not operands:
            polynomial = {(0, 1): 1}
        elif opcode == 3 and len(operands) == 2:
            polynomial = previous(operands[0]).copy()
            for monomial, coefficient in previous(operands[1]).items():
                polynomial[monomial] = polynomial.get(monomial, 0) + coefficient
            polynomial = {key: value for key, value in polynomial.items() if value}
        elif opcode == 4 and len(operands) == 2:
            polynomial = {}
            for (i, j), coefficient in previous(operands[0]).items():
                for (k, ell), other in previous(operands[1]).items():
                    monomial = (i + k, j + ell)
                    polynomial[monomial] = (
                        polynomial.get(monomial, 0) + coefficient * other
                    )
            polynomial = {key: value for key, value in polynomial.items() if value}
        elif opcode == 5 and len(operands) == 1:
            polynomial = {
                monomial: -coefficient
                for monomial, coefficient in previous(operands[0]).items()
            }
        else:
            raise ValueError("Unknown arithmetic operation")

        cache = [[i, j, str(value)] for (i, j), value in sorted(polynomial.items())]
        if expected_entries is not None and cache != expected_entries[index][2]:
            raise ValueError("Original cache is not reproduced exactly")
        caches.append(polynomial)
        restored.append([opcode, operands, cache])

    return json.dumps(json.dumps(restored, separators=(",", ":"))).encode("ascii")


def _pack_record(tag, payload):
    return tag + _SIZE.pack(len(payload)) + payload


def encode_bytes(data):
    """Return a reversible encoding, retaining every unsupported byte verbatim.

    A literal is transformed only after comparing all reconstructed intermediate
    caches with the supplied caches and comparing the entire regenerated literal
    with its original spelling.  Auxiliary literal holders with dummy opcodes
    therefore automatically remain raw.
    """
    if not isinstance(data, bytes):
        raise TypeError("encode_bytes requires bytes")
    records = []
    position = 0
    for match in _LITERAL_PATTERN.finditer(data):
        original_literal = match.group(2)
        try:
            entries = json.loads(json.loads(original_literal))
            if not isinstance(entries, list) or not entries:
                continue
            if not all(isinstance(entry, list) and len(entry) == 3 for entry in entries):
                continue
            operations = [entry[:2] for entry in entries]
            reconstructed = _reconstruct_literal(operations, entries)
            if reconstructed != original_literal:
                continue
            packed = json.dumps(operations, separators=(",", ":")).encode("ascii")
            if len(packed) + 18 >= len(original_literal):
                continue
        except (ValueError, TypeError, IndexError, OverflowError, RecursionError):
            continue
        if match.start(2) > position:
            records.append(_pack_record(b"R", data[position:match.start(2)]))
        records.append(_pack_record(b"P", packed))
        position = match.end(2)
    if position < len(data) or not records:
        records.append(_pack_record(b"R", data[position:]))
    return MAGIC + b"".join(records)


def decode_bytes(encoded):
    """Reconstruct the exact original bytes from encode_bytes' record format."""
    if not isinstance(encoded, bytes):
        raise TypeError("decode_bytes requires bytes")
    if not encoded.startswith(MAGIC):
        raise ValueError("Unsupported lossless sparse encoding")
    position = len(MAGIC)
    parts = []
    while position < len(encoded):
        if len(encoded) - position < 9:
            raise ValueError("Truncated record header")
        tag = encoded[position:position + 1]
        length = _SIZE.unpack_from(encoded, position + 1)[0]
        position += 9
        end = position + length
        if end > len(encoded):
            raise ValueError("Truncated record payload")
        payload = encoded[position:end]
        position = end
        if tag == b"R":
            parts.append(payload)
        elif tag == b"P":
            parts.append(_reconstruct_literal(json.loads(payload)))
        else:
            raise ValueError("Unknown record type")
    return b"".join(parts)


def encoded_stats(encoded):
    """Return record counts and sizes for optional packaging diagnostics."""
    if not encoded.startswith(MAGIC):
        raise ValueError("Unsupported lossless sparse encoding")
    position = len(MAGIC)
    result = {"programs": 0, "program_bytes": 0, "raw_bytes": 0}
    while position < len(encoded):
        tag = encoded[position:position + 1]
        length = _SIZE.unpack_from(encoded, position + 1)[0]
        position += 9 + length
        if tag == b"P":
            result["programs"] += 1
            result["program_bytes"] += length
        elif tag == b"R":
            result["raw_bytes"] += length
        else:
            raise ValueError("Unknown record type")
    return result
